<footer class="py-5 bg-light">
	<div class="container">
		<p class="m-0 text-center text-black">Copyright &copy; Saladman 2020</p>
	</div>
</footer>